package org.javocsoft.push.srv.android.example.server.ack;

import org.javocsoft.push.srv.android.c2dm.ack.ACKInterface;
import org.javocsoft.push.srv.android.c2dm.ack.AndroidACK;
import org.javocsoft.push.srv.android.c2dm.ack.exceptions.C2DMDeviceACKException;

public class ACKImplementation implements ACKInterface {

	@Override
	public boolean receiveACK(AndroidACK arg0) throws C2DMDeviceACKException {
		boolean res=false;
		
		//TODO Logic.
		res=true;
		
		return res;
	}

}
