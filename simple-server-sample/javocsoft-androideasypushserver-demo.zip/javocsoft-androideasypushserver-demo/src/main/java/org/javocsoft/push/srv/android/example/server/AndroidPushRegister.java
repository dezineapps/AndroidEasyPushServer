package org.javocsoft.push.srv.android.example.server;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.javocsoft.push.srv.android.c2dm.C2DMSrvClient;
import org.javocsoft.push.srv.android.c2dm.exceptions.C2DMClientGetAuthTokenException;
import org.javocsoft.push.srv.android.c2dm.json.JSONUtils;
import org.javocsoft.push.srv.android.c2dm.registration.RegistrationInterface;
import org.javocsoft.push.srv.android.c2dm.registration.data.PushDevice;
import org.javocsoft.push.srv.android.c2dm.registration.exceptions.C2DMDeviceRegistrationException;
import org.javocsoft.push.srv.android.example.server.registration.Registration;


/**
 * This servlet follows CRUD standard. Implements the operations
 * for C2DM launched from a device.  
 * 
 * Acts like a RestFull WS providing operations for 
 * 	- Register a Device (HTTP POST)
 *  - Un-register a Device (HTTP DELETE)
 *  - Get registered device information (HTTP GET)
 *  - Activate/Desactivate Push notification for a registered device (HTTP PUT)
 *  
 *  
 */
public class AndroidPushRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	Logger logger=null;
	
	private C2DMSrvClient c2dmClient=null;
	private String c2dmToken=null;
	
	final String c2dm_secure_store_pwd="1234";
	final String c2dm_account_credentials_file="c2dm_account_credentials.c2dm";
	final String c2dm_token_file="c2dm_srv_token.c2dm";
	final String c2dm_serverName="JavocSoftTestServer";
	//C2DM Registration account information.
	//Go to http://code.google.com/intl/es-ES/android/c2dm/signup.html to register.
	final String c2dm_account_sender="";
	final String c2dm_account_sender_pwd="";
	
	
    public AndroidPushRegister() {
        super();
        
    }

    
	public void init(ServletConfig config) throws ServletException {
		logger=Logger.getLogger(AndroidPushRegister.class);
		
		c2dmClient=new C2DMSrvClient(c2dm_secure_store_pwd, c2dm_account_credentials_file, 
									 c2dm_token_file, c2dm_account_sender, 
									 c2dm_account_sender_pwd,c2dm_serverName);
		try{
			//Way 1: With token being saved in disk.
			c2dmToken=c2dmClient.getServerAuthenticationToken(false, true);
			logger.info("Server C2DM AUTH obtained token: "+c2dmToken);
		} catch (C2DMClientGetAuthTokenException e) {
			logger.error("ERROR Server C2DM AUTH obtain token process: "+e.getMessage());
		}
	}
    
	/**
	 * @see Servlet#getServletInfo()
	 */
	public String getServletInfo() {
		
		return null; 
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Registration reg=new Registration();
		String responseText=null;
		
		String registrationId=request.getParameter(RegistrationInterface.REGISTRATION_PARAM_REGISTRATIONID);
		if(registrationId==null){
			responseText=JSONUtils.getJSONStringMessage(JSONUtils.JSON_MODE_MAPPED, JSONUtils.MESSAGE_TYPE_ERROR, registrationId, "Required parameters not found!");
			sendMessageFromServer(response,responseText);
		}else{
			try{
				PushDevice registeredDevice=reg.getRegisterInformation(registrationId);
				
				//Send the result response
				responseText=JSONUtils.getJSONStringFromDeviceInfo(JSONUtils.JSON_MODE_MAPPED, registeredDevice);
				sendMessageFromServer(response,responseText);
				
			} catch (C2DMDeviceRegistrationException e) {
				responseText=JSONUtils.getJSONStringMessage(JSONUtils.JSON_MODE_MAPPED, JSONUtils.MESSAGE_TYPE_ERROR, registrationId, e.getMessage());				
				sendMessageFromServer(response,responseText);
			}
		}
	}

	
	
	@Override
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Registration reg=new Registration();
		String responseText=null;
		String registrationId=null;
		
		try{
			registrationId=request.getParameter(RegistrationInterface.REGISTRATION_PARAM_REGISTRATIONID);
			if(registrationId==null){
				responseText=JSONUtils.getJSONStringMessage(JSONUtils.JSON_MODE_MAPPED, JSONUtils.MESSAGE_TYPE_ERROR, registrationId, "Required parameters not found!");
				sendMessageFromServer(response,responseText);
			}else{
				PushDevice pushDevice=reg.getRegisterInformation(registrationId);				
				boolean res=reg.unregisterDevice(pushDevice);
				
				String jsonInfo=null;
				if(res){
					jsonInfo=JSONUtils.getJSONStringMessage(JSONUtils.JSON_MODE_MAPPED, JSONUtils.MESSAGE_TYPE_INFO, registrationId, "Device successfully unregistered from server.");
				}else{
					jsonInfo=JSONUtils.getJSONStringMessage(JSONUtils.JSON_MODE_MAPPED, JSONUtils.MESSAGE_TYPE_ERROR, registrationId, "Device could not be un-registered from the server, try again later.");
				}
				//Send the result response
				sendMessageFromServer(response,jsonInfo);
			}
		
		} catch (C2DMDeviceRegistrationException e) {
			responseText=JSONUtils.getJSONStringMessage(JSONUtils.JSON_MODE_MAPPED, JSONUtils.MESSAGE_TYPE_ERROR, registrationId, e.getMessage());			
			sendMessageFromServer(response,responseText);
		}
		
	}

	@Override
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Registration reg=new Registration();
		String responseText=null;
		String registrationId=null;
		
		try{
			registrationId=request.getParameter(RegistrationInterface.REGISTRATION_PARAM_REGISTRATIONID);
			if(registrationId==null){
				responseText=JSONUtils.getJSONStringMessage(JSONUtils.JSON_MODE_MAPPED, JSONUtils.MESSAGE_TYPE_ERROR, registrationId, "Required parameters not found!");
				sendMessageFromServer(response,responseText);
			}else{
				PushDevice pushDevice=reg.getRegisterInformation(registrationId);
				
				String activation_flag=request.getParameter(RegistrationInterface.REGISTRATION_PARAM_DEVICEACTIVE);
				pushDevice.setDeviceActive(activation_flag.equalsIgnoreCase("true")?true:false);
				
				pushDevice=reg.updateDeviceRegistration(pushDevice);
				
				String jsonInfo=JSONUtils.getJSONStringFromDeviceInfo(JSONUtils.JSON_MODE_MAPPED, pushDevice);		
				//Send the result response
				sendMessageFromServer(response,jsonInfo);
			}
		
		} catch (C2DMDeviceRegistrationException e) {
			responseText=JSONUtils.getJSONStringMessage(JSONUtils.JSON_MODE_MAPPED, JSONUtils.MESSAGE_TYPE_ERROR, registrationId, e.getMessage());
			sendMessageFromServer(response,responseText);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Registration reg=new Registration();

		
	
			
			PushDevice pushDevice=new PushDevice(request.getParameter(RegistrationInterface.REGISTRATION_PARAM_REGISTRATIONID), request.getParameter(RegistrationInterface.REGISTRATION_PARAM_REGISTRATIONMAIL));
			pushDevice.setDeviceId(request.getParameter(RegistrationInterface.REGISTRATION_PARAM_DEVICEID));
			pushDevice.setDeviceName(request.getParameter(RegistrationInterface.REGISTRATION_PARAM_DEVICENAME));
			pushDevice.setDeviceModel(request.getParameter(RegistrationInterface.REGISTRATION_PARAM_DEVICEMODEL));
			pushDevice.setDeviceOS(request.getParameter(RegistrationInterface.REGISTRATION_PARAM_DEVICEOS));
			
			try {
				//Register the device
				pushDevice=reg.registerDevice(pushDevice);
				
				//Send the result response
				String responseText=JSONUtils.getJSONStringMessage(JSONUtils.JSON_MODE_MAPPED, JSONUtils.MESSAGE_TYPE_INFO, pushDevice.getRegistrationId(), "Device successfully registered.");
				sendMessageFromServer(response,responseText);
				
			} catch (C2DMDeviceRegistrationException e) {
				String responseText=JSONUtils.getJSONStringMessage(JSONUtils.JSON_MODE_MAPPED, JSONUtils.MESSAGE_TYPE_ERROR, pushDevice.getRegistrationId(), e.getMessage());
				sendMessageFromServer(response,responseText);
			}
		
		
	}

	
	
	/*
	 * 
	 * @param response
	 * @param message
	 */
	private void sendMessageFromServer(HttpServletResponse response, String message){
		//Send the result response
		try{
			response.setHeader("Pragma", "No-cache"); 
			response.setHeader("Cache-Control", "no-cache"); 
			response.setDateHeader("Expires", 1);
			
			//Write the response to the client
			PrintWriter writer=response.getWriter();
			writer.print(message);
			writer.flush();
			writer.close();
		}catch(Exception e){
			logger.error("Error sending response ("+message+") to the client because: "+e.getMessage());
		}
	}
	
	
}
