package org.javocsoft.push.srv.android.example.server;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.javocsoft.push.srv.android.c2dm.ack.AndroidACK;
import org.javocsoft.push.srv.android.c2dm.ack.exceptions.C2DMDeviceACKException;
import org.javocsoft.push.srv.android.c2dm.json.JSONUtils;
import org.javocsoft.push.srv.android.example.server.ack.ACKImplementation;


/**
 * This servlet follows CRUD standard. Implements the operations
 * for C2DM launched from a device.  
 * 
 * Acts like a RestFull WS providing operations for 
 * 	- Register an ACK (HTTP POST)
 *  
 */
public class AndroidPushAck extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	Logger logger=null;
	
	
    public AndroidPushAck() {
        super();
        
    }

    
	public void init(ServletConfig config) throws ServletException {
		logger=Logger.getLogger(AndroidPushAck.class);
		
		
	}
    
	/**
	 * @see Servlet#getServletInfo()
	 */
	public String getServletInfo() {
		
		return null; 
	}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ACKImplementation ack=new ACKImplementation();

			
		AndroidACK ackItem=new AndroidACK();
		ackItem.setAid(request.getParameter(ACKImplementation.ACK_PARAM_DEVICEID));
		ackItem.setNotificationId(request.getParameter(ACKImplementation.ACK_PARAM_NOTIFICATIONID));
		ackItem.setRegistrationId(request.getParameter(ACKImplementation.ACK_PARAM_REGISTRATIONID));
			
		try {
			//Register the device
			boolean res=ack.receiveACK(ackItem);
			
			//Send the result response
			String responseText=null;
			if(res){
				responseText=JSONUtils.getJSONStringMessage(JSONUtils.JSON_MODE_MAPPED, JSONUtils.MESSAGE_TYPE_INFO, ackItem.getRegistrationId(), "ACK correctly registered.");
			}else{
				responseText=JSONUtils.getJSONStringMessage(JSONUtils.JSON_MODE_MAPPED, JSONUtils.MESSAGE_TYPE_ERROR, ackItem.getRegistrationId(), "ACK not correctly registered.");
			}
			sendMessageFromServer(response,responseText);
				
		} catch (C2DMDeviceACKException e) {
			String responseText=JSONUtils.getJSONStringMessage(JSONUtils.JSON_MODE_MAPPED, JSONUtils.MESSAGE_TYPE_ERROR, ackItem.getRegistrationId(), e.getMessage());
			sendMessageFromServer(response,responseText);
		}
		
	}

	
	
	/*
	 * 
	 * @param response
	 * @param message
	 */
	private void sendMessageFromServer(HttpServletResponse response, String message){
		//Send the result response
		try{
			response.setHeader("Pragma", "No-cache"); 
			response.setHeader("Cache-Control", "no-cache"); 
			response.setDateHeader("Expires", 1);
			
			//Write the response to the client
			PrintWriter writer=response.getWriter();
			writer.print(message);
			writer.flush();
			writer.close();
		}catch(Exception e){
			logger.error("Error sending response ("+message+") to the client because: "+e.getMessage());
		}
	}
	
	
}
