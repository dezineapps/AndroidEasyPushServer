package org.javocsoft.push.srv.android.example.server.registration;

import java.util.List;

import org.javocsoft.push.srv.android.c2dm.C2DMConstants.TargetServer;
import org.javocsoft.push.srv.android.c2dm.registration.RegistrationInterface;
import org.javocsoft.push.srv.android.c2dm.registration.data.PushDevice;
import org.javocsoft.push.srv.android.c2dm.registration.exceptions.C2DMDeviceRegistrationException;

public class Registration implements RegistrationInterface{

	@Override
	public PushDevice registerDevice(PushDevice deviceToRegister) throws C2DMDeviceRegistrationException {
		
		//TODO
		PushDevice registeredDevice=new PushDevice("registrationId","registrationMail");
		registeredDevice.setDeviceActive(true);
		registeredDevice.setDeviceId("deviceId");
		registeredDevice.setDeviceModel("deviceModel");
		registeredDevice.setDeviceName("deviceName");
		registeredDevice.setDeviceOS("deviceOS");
		registeredDevice.setRegistrationDate(new java.util.Date());
		
		return registeredDevice;
	}

	@Override
	public boolean unregisterDevice(PushDevice pushDevice)
			throws C2DMDeviceRegistrationException {
		
		
		
		return true;
	}

	@Override
	public PushDevice getRegisterInformation(String registrationId)
			throws C2DMDeviceRegistrationException {
		
		//TODO
		PushDevice registeredDevice=new PushDevice("registrationId","registrationMail");
		registeredDevice.setDeviceActive(true);
		registeredDevice.setDeviceId("deviceId");
		registeredDevice.setDeviceModel("deviceModel");
		registeredDevice.setDeviceName("deviceName");
		registeredDevice.setDeviceOS("deviceOS");
		registeredDevice.setRegistrationDate(new java.util.Date());
		
		return registeredDevice;
	}

	@Override
	public boolean activationRegisteredDevice(PushDevice pushDevice,
			boolean activation) throws C2DMDeviceRegistrationException {
		
		//TODO
		
		return true;
	}

	@Override
	public List<PushDevice> listRegisteredDevices(boolean onlyActive)
			throws C2DMDeviceRegistrationException {
		
		return null;
	}

	@Override
	public PushDevice updateDeviceRegistration(PushDevice deviceToRegister)
			throws C2DMDeviceRegistrationException {
		
		//TODO
		
		return deviceToRegister;
	}

	@Override
	public List<PushDevice> listRegisteredDevices(TargetServer target,
			boolean onlyActive) throws C2DMDeviceRegistrationException {
		
		return null;
	}

}
