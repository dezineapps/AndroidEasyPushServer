package org.javocsoft.push.srv.android.example.server.tests;

import org.javocsoft.push.srv.android.c2dm.C2DMSrvClient;
import org.javocsoft.push.srv.android.c2dm.exceptions.C2DMClientGetAuthTokenException;
import org.javocsoft.push.srv.android.c2dm.exceptions.C2DMClientPushException;
import org.javocsoft.push.srv.android.c2dm.operation.info.C2DMOperationInfo;

public class TestC2DMClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		final String c2dm_secure_store_pwd="1234";
		final String c2dm_account_credentials_file="c2dm_account_credentials.c2dm";
		final String c2dm_serverName="JavocSoft Test Server";
		//C2DM Registration account information.
		//Go to http://code.google.com/intl/es-ES/android/c2dm/signup.html to register.
		final String c2dm_account_sender="";
		final String c2dm_account_sender_pwd="";
		
		final String c2dm_token_file="c2dm_srv_token.c2dm";
		
		final String notificationId="1";
		
		String dev_reg_id="some_device_registration_id";
		String[] devices={dev_reg_id,dev_reg_id};
		String richMediaPushUrl="http://www.google.es";
		
		C2DMSrvClient c2dmClient=new C2DMSrvClient(c2dm_secure_store_pwd, c2dm_account_credentials_file, 
												   c2dm_token_file, c2dm_account_sender, 
												   c2dm_account_sender_pwd,c2dm_serverName);
		
		
		try {
			//Way 1: With token being saved in disk.
			c2dmClient.getServerAuthenticationToken(false, true);
			C2DMOperationInfo result=c2dmClient.sendPush(devices, "This is a push test from JavocSoft - AndroidEasyPushServer library.",richMediaPushUrl,notificationId,true,false);
			String[] pushSent=result.getC2DMSentPushNotifications();
			for(String pushData:pushSent){
				System.out.println("PUSH Info: "+pushData);
			}
			
			//Way 2: With token not being saved in disk.
			/*String c2dmToken=c2dmClient.getServerAuthenticationToken(false, false);
			C2DMOperationInfo result=c2dmClient.sendPush(c2dmToken,devices, "This is a push test from JavocSoft - AndroidEasyPushServer library.",richMediaPushUrl,true,false);
			String[] pushSent=result.getC2DMSentPushNotifications();
			for(String pushData:pushSent){
				System.out.println("PUSH Info: "+pushData);
			}*/
			
		} catch (C2DMClientGetAuthTokenException e) {
			e.printStackTrace();
		} catch (C2DMClientPushException e) {
			e.printStackTrace();
		}
		
		
	}

}
