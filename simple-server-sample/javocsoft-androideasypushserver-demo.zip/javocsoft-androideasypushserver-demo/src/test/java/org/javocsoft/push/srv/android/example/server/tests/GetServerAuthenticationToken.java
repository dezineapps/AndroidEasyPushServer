package org.javocsoft.push.srv.android.example.server.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.javocsoft.push.srv.android.c2dm.AndroidC2DM;
import org.javocsoft.push.srv.android.c2dm.credentials.C2DMSenderCredentials;
import org.javocsoft.push.srv.android.c2dm.credentials.SecureC2DMCredentialsStorage;
import org.javocsoft.push.srv.android.c2dm.exceptions.C2DMDecryptCredentialsException;
import org.javocsoft.push.srv.android.c2dm.exceptions.C2DMEncryptCredentialsException;
import org.javocsoft.push.srv.android.c2dm.operation.info.C2DMOperationInfo;

public class GetServerAuthenticationToken {

	final static String c2dm_account_credentials_file="c2dm_account_credentials.c2dm";
	final static String c2dm_token_file="c2dm_srv_token.c2dm";
	final static String c2dm_serverName="JavocSoft Test Server";
	//C2DM Registration account information.
	//Go to http://code.google.com/intl/es-ES/android/c2dm/signup.html to register.
	final static String c2dm_account_sender="";
	final static String c2dm_account_sender_pwd="";
	
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException{
		
		//We create the secure store for credentials
		SecureC2DMCredentialsStorage secStore=new SecureC2DMCredentialsStorage("1234");
				
		try {
			File f=new File(c2dm_account_credentials_file);
			FileOutputStream out=new FileOutputStream(f);
			secStore.saveSecureStore(out, new C2DMSenderCredentials(c2dm_account_sender,c2dm_account_sender_pwd));
			out.close();
			
			//We read the secure store for credentials
			FileInputStream in=new FileInputStream(f);
			C2DMSenderCredentials credentials=secStore.openSecureStore(in);
			in.close();
			
			File fSrvToken=new File(c2dm_token_file);
			FileOutputStream outSrvToken=new FileOutputStream(fSrvToken);
			C2DMOperationInfo result = AndroidC2DM.obtainC2DMAuthenticationToken(c2dm_serverName,credentials,outSrvToken);
			out.close();
			
			if(result.getExceptionsList().size()>0){
				String[] errors=result.getExceptions();
				for(String e:errors){
					System.out.println(e.toString());
				}
			}else{
				System.out.println(result.getC2DMSrvToken());
			}
		} catch (C2DMEncryptCredentialsException e) {
			e.printStackTrace();
		} catch (C2DMDecryptCredentialsException e) {
			e.printStackTrace();
		}
	}

}
